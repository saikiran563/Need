import axios from 'axios';
import { getURL } from '../../../../utils/config';

export const SET_EMAILID = 'contacts/SET_EMAILID'
export const SET_EMAILID_SUCCESS = 'contacts/SET_EMAILID_SUCCESS'
export const SET_EMAILID_ERROR = 'contacts/SET_EMAILID_ERROR'
export const CLEAR_CONTACT_AND_BILLING_CODES = "CLEAR_CONTACT_AND_BILLING_CODES"
export const SHOW_LOADER = "SHOW_LOADER"
export const FETCH_CONTACT_AND_BILLING_BEGIN = 'contacts/FETCH_CONTACT_AND_BILLING_BEGIN'

export const USER_NOT_VERIFIED = "USER_NOT_VERIFIED"

export const clearContactAndBillingCodes = () => dispatch => {
  dispatch({
    type: CLEAR_CONTACT_AND_BILLING_CODES
  })
}

export const setEmailId = data => async dispatch => {
  // API CAll WILL BE CALLED HERE
  // "http://www.mocky.io/v2/5b800c353400004d00dc0707"
  // getURL('SET_EMAIL_INFO')
  dispatch(showLoader());
  const response = await axios({
    method: "post",
    url: getURL('SET_EMAIL_INFO'),
    timeout: 30000, // Let's say you want to wait at least 30 secs
    data: data
  }).catch(err => {
    dispatch(getEmailIdError(err));
  });

  // response.data.data = {};
  // response.data.data.statusCode = "0";
  // response.data.errorCode = "123"
  // response.data.securePinVerified = false;

  if(response){
    if (
      response.data.securePinVerified === undefined ||
      response.data.securePinVerified === null
    ) {
      if (response.data.hasOwnProperty("data")) {
        if (response.data.data.hasOwnProperty("statusCode")) {
          if (response.data.data.statusCode == 0) {
            dispatch(setEmailIdonSuccess(data));
            dispatch(getEmailIdSuccess(response.data.data.statusCode));
          } else {
            dispatch(getEmailIdError(response.data.errorCode));
          }
        } else {
          dispatch(getEmailIdError("error"));
        }
      } else {
        dispatch(getEmailIdError("error"));
      }
    } else {
      dispatch({
        type: USER_NOT_VERIFIED
      });
    }
  } else {
    dispatch(getEmailIdError("error"))
  }
}

export const getEmailIdSuccess = (response) => ({
  type: SET_EMAILID_SUCCESS,
  status : response,
});

export const resetEmailStatus = (response) => dispatch => {
  dispatch({
    type: SET_EMAILID_SUCCESS,
  status : response,
  } )
}

export const setEmailIdonSuccess = (response) => ({
  type: SET_EMAILID,
  response
});

export const getEmailIdError = (response) => ({
  type: SET_EMAILID_ERROR,
  status: response,
})

export const showLoader = () => ({
  type: FETCH_CONTACT_AND_BILLING_BEGIN
})

