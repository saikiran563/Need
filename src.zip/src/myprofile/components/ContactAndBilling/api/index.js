/**
" * Mocking client-server processing
 */
import _profile from './userContacts.json';
import axios from 'axios';
import  { getURL, storedHeaders } from "../../../../utils/config";

const TIMEOUT = 500

// export const getContactAndBillingInfoApi = (cb) => dispatch =>{

//   dispatch(showLoader());

//   axios.get(getURL('GET_CD_INFO'))
//     .then(response => cb(response))
//      .catch(err => cb(err))
 
// }

export const getContactAndBillingInfoApi = (cb) => {
 
  axios.get(getURL('GET_CD_INFO'),storedHeaders())
    .then(response => cb(response))
     .catch(err => cb(err))
 
}

export const showLoader = () => ({
  type: FETCH_CONTACT_AND_BILLING_BEGIN
})
