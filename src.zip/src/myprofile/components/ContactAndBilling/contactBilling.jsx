import React, { Component } from "react";

import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import EmailBlock from "./emailBlock";
import PrimaryPhoneBlock from "./primaryPhoneBlock";
import BillingAddressBlock from "./billingAddressBlock";
import ServiceAddressBlock from "./serviceAddressBlock";
import Spinner from "../Spinner/Spinner";
import Modal from "../Modal/modal"
import { getErrorMsgByCode } from "../../../utils/config"
import * as actions from "./actions";
import ErrorBoundary from '../QuickLinks/ErrorBoundary'

import "./style.css";
require("../../../assets/css/main.css");
require("../../../assets/css/my-profile.css");
require("../../../assets/css/oneD-Global.css");
require("../../../assets/css/phoenixGlobal.css");

class ContactAndBilling extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showEmailEdit: true,
      userEditMode: true,
      primaryPhoneEditMode: true,
      showPrimaryPhoneEdit: true,
      showBillingEdit: true,
      billingAddressEditMode: true,
      showServiceAddress: true,
      serviceAddressEditMode: true,
      serviceAddressSaved: false,
      emailOkContinue: false,
      
    };
  }
  componentDidMount() {
    document.addEventListener("click", event => {
      this.setState({
        event: event.timeStamp
      })
      // console.log(event);
    });

    if(!this.props.contactDetails)
    this.props.actions.fetchContactAndBillingInitial();

    const URL_MAP = this.props.match.url.split("/");
    const type = URL_MAP[URL_MAP.length - 1];
    type ? this.handleEditCancel(type + "Block") : "";
  }

componentWillReceiveProps (nextprops){
  if(nextprops.shouldCallContactandBilling && (nextprops.serviceAddressStatus == '0' || nextprops.billingAddressStatus == '0') && !nextprops.contactDetailSuccess){
    this.props.actions.editAddressOrLineClicked();
    this.handleEditCancel('');
    this.props.actions.fetchContactAndBillingBegin();
    this.props.actions.fetchContactAndBilling();
   
    sessionStorage.setItem('toShowSaved','true');
   // this.props.actions.cancelButtonClicked();
  }
}


  resetStatus() {
    this.props.actions.resetEmailStatus(null);
    this.props.actions.resetPrimaryPhoneStatus(null);
    // this.props.actions.resetBillingAddressStatus(null);
    this.props.actions.resetServiceAddressStatus(null);
  }
  setEmailStatus() {
    this.props.actions.resetEmailStatus('error');
  }
  setBillingAddressStatus() {
    this.props.actions.resetBillingAddressStatus('error');
  }

  handleEditCancel = type => {
      sessionStorage.clear();
    switch (type) {
      case "emailBlock":
        this.setState({
          showEmailEdit: false,
          showPrimaryPhoneEdit: false,
          primaryPhoneEditMode: false,
          userEditMode: true,
          billingAddressEditMode: false,
          showBillingEdit: false,
          showServiceAddress: false,
          serviceAddressEditMode: false,
          
        });
        // this.props.history.push("/contactbilling/email");
        // this.setEmailStatus();
        if(document.getElementById('email_block')){
          setTimeout(()=>{
          let element = document.getElementById('email_block');
          const y = element.getBoundingClientRect().top + window.scrollY;
          console.log("email ->",y)
          if(element.offsetHeight>208){
            window.scroll({
              top:element.offsetTop+90,
              behavior:'smooth'
            })
          }
          else{
            window.scroll({
              top: y+40,
              behavior: 'smooth'
            });
          }
          },300)
            
        }

        //document.getElementById('email_block').scrollIntoView(true);
        
        break;
      case "primaryPhoneBlock":
        this.setState({
          showEmailEdit: false,
          showPrimaryPhoneEdit: false,
          primaryPhoneEditMode: true,
          userEditMode: false,
          billingAddressEditMode: false,
          showBillingEdit: false,
          showServiceAddress: false,
          serviceAddressEditMode: false,
          
        });
        // this.resetStatus();
        // this.props.history.push("/contactbilling/primaryPhone");
        if(document.getElementById('contact_block')){
          setTimeout(()=>{
          let element = document.getElementById('contact_block');
           const y = element.getBoundingClientRect().top + window.scrollY;
            console.log("phone ->",y)
            if(element.offsetHeight>298){
              window.scroll({
                top: element.offsetTop+90,
                behavior: 'smooth'
              });
            }
            else{
              window.scroll({
                top: element.offsetTop+40,
                behavior: 'smooth'
              });
            }
          },300)
            
        }
         //document.getElementById('contact_block').scrollIntoView(true);
         
        break;
      case "billingAddressBlock":
        this.setState({
          showEmailEdit: false,
          showPrimaryPhoneEdit: false,
          primaryPhoneEditMode: false,
          showBillingEdit: false,
          userEditMode: false,
          billingAddressEditMode: true,
          showServiceAddress: false,
          serviceAddressEditMode: false,
          
        });
        // this.setBillingAddressStatus();
        // this.props.history.push("/contactbilling/billingAddress");
        if(document.getElementById('billing_block')){
          setTimeout(()=>{
           let element = document.getElementById('billing_block');
           const y = element.getBoundingClientRect().top + window.scrollY;
            console.log("billing ->",y)
            if(element.offsetHeight>396){
              window.scroll({
              top: element.offsetTop+90,
              behavior: 'smooth'
            });
            }
            else{
            window.scroll({
              top: y+40,
              behavior: 'smooth'
            });
            }
          },300)
        }
        // document.getElementById('billing_block').scrollIntoView(true);
       
        break;
      case "serviceAddressBlock":
        this.setState({
          showEmailEdit: false,
          showPrimaryPhoneEdit: false,
          primaryPhoneEditMode: false,
          showBillingEdit: false,
          userEditMode: false,
          billingAddressEditMode: false,
          showServiceAddress: true,
          serviceAddressEditMode: true,
          
        });
      
       
        this.props.actions.editAddressOrLineClicked(false);
       // this.props.history.push("/contactbilling/serviceAddress");
         if(document.getElementById('service_block')){
           setTimeout(()=>{
           let element = document.getElementById('service_block');
           const y = element.getBoundingClientRect().top + window.scrollY;
            console.log("service ->",y)
            if(element.offsetHeight > 800){
              window.scroll({
              top: element.offsetTop+90,
              behavior: 'smooth'
            });
            }else{
            window.scroll({ 
              top: 400,
              behavior: 'smooth'
            });
            }
           },300) 
         }
        // document.getElementById('service_block').scrollIntoView(true);
       
        break;
      default:
        // this.resetStatus();
        // this.props.history.push("/contactbilling");
        this.props.actions.editAddressOrLineClicked();
        window.scroll({
              top: 0,
              behavior: 'smooth'
            });
        this.setState({
          showEmailEdit: true,
          showPrimaryPhoneEdit: true,
          userEditMode: true,
          primaryPhoneEditMode: true,
          billingAddressEditMode: true,
          showBillingEdit: true,
          showServiceAddress: true,
          serviceAddressEditMode: true,
          
        });

         // window.scrollTo(0,0);
    }
  };

  handleOkContinue = () => {
     this.setState({
          showEmailEdit: true,
          showPrimaryPhoneEdit: true,
          userEditMode: true,
          primaryPhoneEditMode: true,
          billingAddressEditMode: true,
          showBillingEdit: true,
          showServiceAddress: true,
          serviceAddressEditMode: true         
        });
        this.props.history.push("/contactbilling");
  }

  handleSave = (formId, formData, event) => {
    // through an API call.
    // event.preventDefault();
    switch (formId) {
      case "emailBlock":
      this.props.actions.setEmailId(formData);
        // this.setState({
        //   showEmailEdit: true,
        //   showPrimaryPhoneEdit: true,
        //   userEditMode: true,
        //   primaryPhoneEditMode: true,
        //   billingAddressEditMode: true,
        //   showBillingEdit: true,
        //   showServiceAddress: true,
        //   serviceAddressEditMode: true,
          
        // });
        break;
      case "primaryPhoneBlock":
        this.props.actions.setPrimaryPhone(formData);
        this.setState({
          phoneSaved: true,
          showEmailEdit: true,
          showPrimaryPhoneEdit: true,
          userEditMode: true,
          primaryPhoneEditMode: true,
          billingAddressEditMode: true,
          showBillingEdit: true,
          showServiceAddress: true,
          serviceAddressEditMode: true,
          
        });
        break;
      case "billingAddressBlock":
        this.props.actions.updateBillingAddress(formData);
        this.setState({
          showEmailEdit: true,
          showPrimaryPhoneEdit: true,
          userEditMode: true,
          primaryPhoneEditMode: true,
          billingAddressEditMode: true,
          billingAddressSaved: true,
          showBillingEdit: true,
          showServiceAddress: true,
          serviceAddressEditMode: true,
          
        });
        //this.props.actions.showModalPopup();
        break;
      case "serviceAddressBlock":
        this.props.actions.updateServiceAddress(formData);
        break;
    }
    //To remove saved after 20 sec
    setTimeout(() => {
   //  this.resetStatus()
    }, 10000);
  };

  closeModal = () => {
    this.props.actions.clearContactAndBillingCodes()
  }
  render() {
    const {
      contactDetails,
      showSpinner,
      emailStatus,
      primaryPhoneStatus,
      billingAddressStatus,
      serviceAddressStatus,
      contactDetailSuccess,
      initialFetch,
      getCbError,
    } = this.props;

    let acctHolder =
      reactGlobals.mdnRole.toLocaleLowerCase() == "accountholder";

    let acctManger =
      reactGlobals.mdnRole.toLocaleLowerCase() == "accountmanager";

    return (
      <div className="aMyProfile__CB">
        {(!contactDetails || showSpinner) && !getCbError ? <Spinner /> : null}
       { !getCbError && <h2 className="title title--lg">Contact & Billing</h2> }
       <div> { getCbError && <ErrorBoundary/> } </div>
        {contactDetails && (
          <div className="col-xs-12">
          <div id="email_block">
            <EmailBlock
              userEmailInfo={contactDetails}
              handleEditCancel={type => this.handleEditCancel(type)}
              handleSave={(type, data, e) => this.handleSave(type, data, e)}
              handleOkContinue={() => this.handleOkContinue()}
              emailStatus={emailStatus}
              {...this.state}
            /></div>
          {(acctHolder || acctManger) && <div id="contact_block"> <PrimaryPhoneBlock
              userPrimaryPhoneInfo={contactDetails}
              handleEditCancel={type => this.handleEditCancel(type)}
              handleSave={(type, data, e) => this.handleSave(type, data, e)}
              primaryPhoneStatus={primaryPhoneStatus}
              {...this.state}
          /></div> }
            {(acctHolder || acctManger) && (
              <div id="billing_block">
              <BillingAddressBlock
                userBillingInfo={contactDetails.billingAddress}
                handleEditCancel={type => this.handleEditCancel(type)}
                handleSave={(type, data, e) => this.handleSave(type, data, e)}
                billingAddressStatus={billingAddressStatus}
                {...this.state}
              /></div>
            )}
            {(acctHolder || acctManger) && (
              <div id="service_block">
              <ServiceAddressBlock
                userServiceAddressInfo={contactDetails.userServiceAddressInfo}
                initialFetch={initialFetch}
                handleSave={(type, data, e) => this.handleSave(type, data, e)}
                addressListOnAccount={contactDetails.addressListOnAccount}
                handleEditCancel={type => this.handleEditCancel(type)}
                editAddressClicked={this.props.editAddressOrLineClicked}
                serviceAddressStatus={serviceAddressStatus}
                contactDetailSuccess={contactDetailSuccess}
                {...this.state}
              /></div>
            )}
          </div>
        )}

      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    contactDetails: state.contactDetails.list,
    getCbError: state.contactDetails.getCbError,
    initialFetch:state.contactDetails.initialFetch,
    showSpinner: state.contactDetails.isFetching,
    emailStatus: state.contactDetails.emailStatus,
    primaryPhoneStatus: state.contactDetails.primaryPhoneStatus,
    billingAddressStatus: state.contactDetails.billingAddressStatus,
    serviceAddressStatus: state.contactDetails.serviceAddressStatus,
    shouldCallContactandBilling: state.contactDetails.shouldCall,
    contactDetailSuccess:state.contactDetails.contactDetailSuccess,
    editAddressOrLineClicked: state.contactDetails.editAddressOrLineClicked,
    serviceAddressFailure: state.contactDetails.serviceAddressFailure
  };
};

const mapDispatchToProps = dispatch => ({
  actions: bindActionCreators(actions, dispatch)
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ContactAndBilling);

