﻿import React from "react";

const TermsAndCoditions = (props) => {
  console.log("Sai Kiran",props.newManagerDetails)
  return (
    <div id="overlayFrame acctmanagement-TandC's" className="animated fadeIn a-fast">
    <span className="close-wrapper">
        <a id="overlayClose" role="button">
          <span className="a-sr a-sr-fix" aria-hidden="false" onClick={(e) => props.onClosePopup(e)}>Close</span>
          <span className="a-icon-overlay-close" aria-hidden="true" onClick={(e) => props.onClosePopup(e)}></span>
        </a>
      </span>
    <div className="modal_content">
      <h1 className="title title--lg">Account Managers</h1>
      <div className='row seperator' />
      <br aria-hidden="true" />
      <br aria-hidden="true" />
      <h2>Review and Accept Terms and Conditions</h2>
      <br/>
      <p>Please read the Account Manager Authorization Terms and Conditions. Select the “Continue” button below to process your request.</p>
      <br/>
      <p>You have requested the following Account Manager(s) be added to your wireless account. You confirm that the requested Account Manager(s) is/are at least 18 years of age (or 19 years of age if a resident of Albama or Nebraska), and you authorize the requested Account Manager(s) to enter into contracts and perform all transactions regarding your account, except those transactions excluded below.</p>
      <br/>
      <div className="row">
      <div className="col-xs-12 col-sm-12 col-lg-3">
            <h2>{props.newManagerDetails.firstName} {props.newManagerDetails.lastName} </h2>
          </div>
          {props.newManagerDetails.phoneNumber!='noLineAssigned' &&
            <div className="col-xs-12 col-sm-12 col-lg-3">
              <h2>{props.newManagerDetails.phoneNumber}</h2>
            </div>
          } <div className="col-xs-12 col-sm-12 col-lg-3">
            <h2>{props.newManagerDetails.emailId}</h2>
          </div>
        </div>

      <br/>
      <p>You accept that you will be responsible for all changes made to your account(s) by the Account Manager(s).</p>
      <br/>
      <p>You are responsible for providing the Account PIN to each Account Manager. Account Managers must know the Account PIN in order to access information or perform transactions on the account.</p>
      <br/>
      <p>Please carefully review the Account Manager’s authority below prior to accepting.</p>
      <br/>
      <h2>Account Manager’s Authority</h2>
      <br/>
      <p>Account Managers may perform all the same transactions as the Account Owner, online, in retail locations, and by calling Customer Service, EXCEPT for the following:</p>
      <br/>
      <p>•  Add, Change, or delete Account PIN.</p>
      <p>•  Add, Change, or delete other Account Managers.</p>
      <br/>
      <br aria-hidden="true" />
      <br aria-hidden="true" />
      <div className="rol-permissions__buttons">
      <div className="col-xs-12">
        <button className="btn btn--round-invert btnclose" onClick={(e) =>props.onClosePopup(e)} analyticstrack="accountmanager-close">Close</button>
        <button className="btn btn--round btnclose ml-1"
              style={{ 'width': '115px', 'text-decoration':'none'}}
                role="button"  onClick={(e) =>props.onContinue(e)} analyticstrack="accountmanager-continue">Continue</button>
    </div>
    </div>
    </div>
    </div>
  );
};

export default TermsAndCoditions;
