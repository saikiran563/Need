// const BASE_URL = 'https://vzwqa2.verizonwireless.com/ui/acct/secure'

// //export const GET_MANAGE_LANDING_URL = BASE_URL + '/data/secure/profile/accountmanager'
// export const GET_ACCOUNT_MANAGE_URL =  BASE_URL + '/data/secure/profile/accountmanager'
// //export const GET_ACCOUNT_MEMBER_DETAILS =  BASE_URL + '/data/am/profile/pendingRequests'
export const ADD_MANAGER_URL = "http://www.mocky.io/v2/5bacb07b3100004b00654903"//'https://api.myjson.com/bins/pj2tw' //http://www.mocky.io/v2/5bacaf7a31000061006548e9 //BASE_URL + '/data/ahonly/profile/modifyacctmgr'
export const REMOVE_MANAGER_URL =  "http://www.mocky.io/v2/5bacaf3831000072006548e7"//"http://www.mocky.io/v2/5ba469802f00002a00968b68" //BASE_URL + '/data/ahonly/profile/downgradeacctmgr'
// //export const SEND_ACCOUNT_MANGER_REQUEST_URL = BASE_URL + '/data/am/profile/accountManagerRequest'
export const APPROVE_MANAGER_URL = "http://www.mocky.io/v2/5bacb07b3100004b00654903" //BASE_URL + '/data/ahonly/profile/accountManagerRequest'
export const DENY_MANAGER_URL = "http://www.mocky.io/v2/5b732d733200005c083a7ff2"//BASE_URL + '/data/ahonly/profile/accountManagerRequest'
export const GET_MTNS_URL = "https://api.myjson.com/bins/ths6c" /*BASE_URL +  '/data/ao/profile/mtns'*/  //'https://api.myjson.com/bins/1h8ais'//'https://api.myjson.com/bins/18szgo'
// //export const GET_MANAGER_REQUESTS_URL =  https://api.myjson.com/bins/15i5oo //BASE_URL +  '/data/ahonly/profile/pendingRequests' 
// //export const POST_GREETING_NAME_URL =  BASE_URL + '/data/secure/profile/greetingname'
export const GET_ACCOUNT_MEMBER_DETAILS_URL = "https://api.myjson.com/bins/v5yrk"//https://api.myjson.com/bins/1c42i0  //BASE_URL+ '/data/secure/profile/userDetails' 


 export const GET_MANAGE_LANDING_URL = /*"https://api.myjson.com/bins/1e81zs"*//*"https://api.myjson.com/bins/ku9qw"*/ "https://api.myjson.com/bins/10g2z8"//"https://api.myjson.com/bins/fx6qw" 
 export const GET_MANAGER_REQUESTS_URL = "https://api.myjson.com/bins/qvuxc"//'https://api.myjson.com/bins/jdd9s'  //https://api.myjson.com/bins/jdd9s            //'https://mypf-2a66b.firebaseio.com/pendingRequests.json'
 export const POST_GREETING_NAME_URL =  'https://mypf-2a66b.firebaseio.com/activemanagers.json'
 export const SEND_ACCOUNT_MANGER_REQUEST_URL = "http://www.mocky.io/v2/5bacb07b3100004b00654903" //'https://mypf-2a66b.firebaseio.com/pendingRequests/customerInfo.json'
