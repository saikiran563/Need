const FETCH_PRIVACY_AND_PERMISSIONS_BEGIN = 'privacies/FETCH_PRIVACY_AND_PERMISSIONS_BEGIN'
const FETCH_PRIVACY_AND_PERMISSIONS_SUCCESS = 'privacies/FETCH_PRIVACY_AND_PERMISSIONS_SUCCESS'
import { POST_PRIVACY_PERMISSIONS, POST_PRIVACY_PERMISSIONS_FAIL, GET_PRIVACY_ERROR } from "../actions/fetchPrivacyDetails"

import {
  createReducer,
  updateObject,
  updateItemInArray,
} from '../../../../utils/reducer'


const initialState = {
  // privacyDetails: null,
  isFetching: false,
  // show: false,
  verizonSelectsInfo: {},
  privacySettingsInfo: {},
  businessAndMarketingInfo: {},
  mobileAdvertisingInfo: {},
  privacySettings: null,
  error: "",
  getPrivacyError: ""
}


const fetchPrivacyAndPermissionsBegin = (state, action) => {
  return updateObject(state, { isFetching: true, getPrivacyError: false })
}


const fetchPrivacyAndPermissionsSuccess = (state, action) => {
  console.log("ACTION PRIVACIES", action.payload)
  return updateObject(state, {
    isFetching: false,
    privacySettings: action.payload,
    getPrivacyError: false
    // privacySettingsInfo: action.privacies.privacySettingsInfo,
    // verizonSelectsInfo: action.privacies.verizonSelectsInfo,
    // businessAndMarketingInfo: action.privacies.businessAndMarketing,
    // mobileAdvertisingInfo: action.privacies.mobileAdvertising
  })
}

const getPrivacyError = (state , action) => {
  return updateObject(state, {
    isFetching :false,
    getPrivacyError: true
  })
}

const privacyDetailsReducer = (state = initialState, action) => {
  const { type } = action
  switch (type) {
    case FETCH_PRIVACY_AND_PERMISSIONS_BEGIN:
      return fetchPrivacyAndPermissionsBegin(state, action)
    case FETCH_PRIVACY_AND_PERMISSIONS_SUCCESS:
      return fetchPrivacyAndPermissionsSuccess(state, action)
      case GET_PRIVACY_ERROR:
      return getPrivacyError(state,action)
    case POST_PRIVACY_PERMISSIONS: 
      console.log(action.payload)
      return {
        ...state,
        privacySettings: action.payload
      }
      case POST_PRIVACY_PERMISSIONS_FAIL:
        return {
          ...state,
          error: action.payload
        }
    default:
      return state
  }
}


export default privacyDetailsReducer