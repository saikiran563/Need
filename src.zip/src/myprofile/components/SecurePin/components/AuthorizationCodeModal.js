import React from "react";
import Spinner from "../../Spinner/Spinner"

const AuthorizationCodeModal = props => {
    return (
        <div>
          <h1 className="title title--lg">
            Now enter your authorization code below.
          </h1>
          <p>
            We just texted you a new code. You should receive your code in less
            than a minute.
          </p>
          <p>
            <strong>Authorization Code (all numeric):</strong>
          </p>
          {props.fetchingSecurePin || props.fetchingManageAccount || props.showSpinner ? <Spinner /> : ""}
          <input
            type="text"
            value={props.authorizationCode}
            name="authorizationCode"
            onChange={props.handleAuthCodeChange}
            maxLength="6"
          />
          {props.confirmSecurePinError ? (
            <p className="errorDisplay">
              <span className="fa fa-exclamation-circle" /> 
              {props.confirmSecurePinError}
            </p>
          ) : (
            ""
          )}

          <button
            className="btn btn--round"
            disabled={
              !props.authorizationCode ||
              isNaN(parseInt(props.authorizationCode)) ||
              props.authorizationCode.length < 6
            }
            style={{ marginRight: "10px" }}
            onClick={props.authorizationCodeConformation}
          >
            Confirm
          </button>
          <button
            className="btn btn--round-invert"
            onClick={props.closeModal}
            style={{ cursor: "pointer" }}
          >
            Cancel
          </button>
        </div>
      );
}

export default AuthorizationCodeModal;