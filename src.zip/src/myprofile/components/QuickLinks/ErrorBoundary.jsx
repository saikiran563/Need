import React from 'react';
import styled from 'styled-components';

const ErrorWrapper = styled.div`
  align-items: center;
  font-size: 30px;
  width:auto;
  justify-content: center;
  color:black
`;


class ErrorBoundary extends React.PureComponent {

  render() {
    return(
      <ErrorWrapper>
        <h1 className='title-lg' style={{marginBottom:10}}>Ooops! something went wrong.</h1>
        <p>We are experiencing some issues. Please try again later.</p>
        </ErrorWrapper> 
    );
  }
}

export default ErrorBoundary;