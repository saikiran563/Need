import axios from 'axios'
import mockAPI from '../api'

export const FETCH_ENHANCED_AUTH_EDIT_BEGIN = 'FETCH_ENHANCED_AUTH_EDIT_BEGIN';

export const FETCH_ENHANCED_AUTH_EDIT_SUCCESS = 'FETCH_ENHANCED_AUTH_EDIT_SUCCESS';
export const FETCH_ENHANCED_AUTH_RESET ='FETCH_ENHANCED_AUTH_RESET';

export const CLEAR_ENHANCED_AUTH_ERROR_CODES = "CLEAR_ENHANCED_AUTH_ERROR_CODES"

import  { getURL,encrypt, decrypt, BASE_URL, API_NAME, storedHeaders } from "../../../../utils/config"

export const clearEnhancedAuthErrors = () => dispatch => {
  dispatch({
    type: CLEAR_ENHANCED_AUTH_ERROR_CODES
  })
}

export const fetchEnhAuthEdit = () => dispatch => {
dispatch(fetchEnhAuthEditBegin())

  // mockAPI.fetchEnhAuthEdit(response => {
  //   dispatch(fetchEnhancedAuthEdit(response))
  // })
  // http://localhost:3000/enauth
  // https://vzwqa2.verizonwireless.com/ui/acct/secure/data/ao/profile/twoFactorAuth
  axios.interceptors.request.use(function (config) {
     
    // show loader
    return config;
}, function (error) {
    return Promise.reject(error);
});

// Add a response interceptor

const myInterceptor = axios.interceptors.response.use(function (response) {
  
    // console.log("------------  Ajax pending",response);
  
     (dispatch(fetchEnhancedAuthEdit(response.data)));
     axios.interceptors.response.eject(myInterceptor);
    return response;
}, function (error) {
    return Promise.reject(error);
});

  axios.get(getURL('GET_ENHANCED_AUTH'), storedHeaders())
    .then((response) => {
   
    })
     .catch((err) => {
       dispatch()
      })
      
   
}

// export const fetchEnhAuthEdit = () => dispatch => {
//   axios.get("http://www.mocky.io/v2/5b6765353200000810ee127e") //EDIT API 
//   .then((response) => {

//     dispatch(fetchEnhancedAuthEdit(response.data));
//   })
//   .catch((err) => {
//     dispatch()
//   })

// }

export const fetchEnhAuthEditBegin = () => ({
  type: FETCH_ENHANCED_AUTH_EDIT_BEGIN,
})

export const fetchEnhancedAuthEdit = (enhancedAuth) => ({
  type: FETCH_ENHANCED_AUTH_EDIT_SUCCESS,
  enhancedAuth
})

 