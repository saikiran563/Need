vz-react release 0.1
test
edit from child
