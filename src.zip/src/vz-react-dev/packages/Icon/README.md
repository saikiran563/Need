CSS
===

```
.vz-odt--icon {
    width: 1rem;
    height: 1rem;
}

.vz-odt--icon:hover {
    fill: #999999;
}

.vz-odt--icon > svg > g {
    fill: #999999;
}


```