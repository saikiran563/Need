export const pxToRem = (size, defaultSize = 16) => size / defaultSize

export const resolve = defaultValue => props => {
  if (!props.length) return defaultValue
}
