import {
  FETCH_MANAGE_LANDING_BEGIN,
  FETCH_MANAGE_LANDING_SUCCESS,
  FETCH_MANAGE_LANDING_FAIL,
  FETCH_MTNS_SUCCESS,
  FETCH_MANAGER_REQUESTS_SUCCESS,
  GET_ACCOUNT_MEMBER_DETAILS_SUCCESS,
  ADD_NEW_MANAGER_BEGIN,
  ADD_NEW_MANAGER_SUCCESS,
  ADD_NEW_MANAGER_FAIL,
  SHOW_LEARN_MORE_POPUP,
  HIDE_LEARN_MORE_POPUP,
  APPROVE_MANAGER_BEGIN,
  APPROVE_MANAGER_SUCCESS,
  APPROVE_MANAGER_FAIL,
  CLEAR_ERROR_CODES,
  USER_NOT_VERIFIED,
  REMOVE_MANAGER_BEGIN,
  REMOVE_MANAGER_SUCCESS,
  REMOVE_MANAGER_FAIL,
  UNDO_REMOVE_MANAGER_BEGIN,
  UNDO_REMOVE_MANAGER_SUCCESS,
  UNDO_REMOVE_MANAGER_FAIL,
  DENY_MANAGER_BEGIN,
  DENY_MANAGER_SUCCESS,
  DENY_MANAGER_FAIL,
  SEND_ACCOUNT_MANGER_REQUEST_BEGIN,
  SEND_ACCOUNT_MANGER_REQUEST_SUCCESS,
  SEND_ACCOUNT_MANGER_REQUEST_FAIL
} from '../actions/manage'

const initialState = {
  managers: [],
  addedManager: [],
  revokedManager: {},
  accountManagerRequests: [],
  mtns: [],
  emailId: '',
  phoneNumber:'',
  encryptedPhoneNumber:'',
  deniedAccountManagerRequests: [],
  showRequestSuccessPopup: false,
  showSpinner: true,
  newAccountMemberRequest:  {
      status: 'not requested' // other Status:  request pending , request denied
  },
  showLearnMorePopUp: false,
  approveManagerError: "",
  addManagerError: "",
  userVerified: null,
  manageSecurePinStarted: false,
  fetchingManageAccount: false,
  removeManagerError: {},
  undoRemoveManagerError: {},
  sendAccountManagerRequestError: "",
  denyManagerError: {},
  removeManagerSpinner: false,
  getManageError: ""
}

import {
  createReducer,
  updateObject,
  updateItemInArray,
} from '../../../../utils/reducer'

const accManagerReducer = (state = initialState, action) => {
  const { type } = action
  switch (type) {
    case USER_NOT_VERIFIED:
      return {
        ...state,
        userVerified: false,
        manageSecurePinStarted: true,
        fetchingManageAccount: false,
        showSpinner: false,
        removeManagerSpinner: false
      }
    case CLEAR_ERROR_CODES:
      return {
        ...state,
        approveManagerError: "",
        addManagerError: "",
        manageSecurePinStarted: false,
        removeManagerError: {},        
        undoRemoveManagerError: {},
        sendAccountManagerRequestError: "",
        denyManagerError: {}
      }
    case ADD_NEW_MANAGER_BEGIN:
      return {
        ...state,
        userVerified: null,
        fetchingManageAccount: true
      }
    case ADD_NEW_MANAGER_SUCCESS:
      return {
        ...state,
        fetchingManageAccount: false,        
        managers: [...state.managers, action.response.data],
        addedManager: action.response.data,
        addManagerError: "",
        mtns: state.mtns.filter(item => item.mdn !== action.response.data.phoneNumber)
      }
    case ADD_NEW_MANAGER_FAIL:
      return {
        ...state,
        addManagerError: action.error,
        fetchingManageAccount: false
      }
    case APPROVE_MANAGER_BEGIN:
      return {
        ...state,
        userVerified: null,
        fetchingManageAccount: true
      }
    case APPROVE_MANAGER_SUCCESS:
      return {
        ...state,
        managers: [...state.managers, action.response.data],
        accountManagerRequests: [...state.accountManagerRequests.filter(accountMember => accountMember.phoneNumber != action.response.data.phoneNumber)],
        approveManagerError: "",
        manageSecurePinStarted: false,
        fetchingManageAccount: false,
        mtns: state.mtns.filter(item => item.mdn !== action.response.data.phoneNumber)
        // userVerified: null
      }
    case APPROVE_MANAGER_FAIL:
     return {
       ...state,
       approveManagerError: action.error,
       manageSecurePinStarted: false,
       fetchingManageAccount: false   
     }
    case DENY_MANAGER_BEGIN: {
      return {
        ...state,
        showSpinner: true
      }
    }
    case DENY_MANAGER_SUCCESS:
    const newArray = state.accountManagerRequests.filter(item => item.phoneNumber !== action.response.phoneNumber)

      return {
        ...state,
        showSpinner: false,
        accountManagerRequests: newArray,
        deniedAccountManagerRequests: [...state.deniedAccountManagerRequests, action.response],
        denyManagerError: {}
      }
    case DENY_MANAGER_FAIL: {
      return {
        ...state,
        showSpinner: false,
        denyManagerError: action.payload
      }
    }
    case FETCH_MANAGE_LANDING_BEGIN:
      return updateObject(state, {
        showSpinner: true, getManageError: false
      })

    case FETCH_MANAGE_LANDING_SUCCESS:
      return updateObject(state, {
        managers: action.response.customerInfo,
        amgrCount: action.response.amgrCount,
        showSpinner: false,
        getManageError: false
      })

      case FETCH_MANAGE_LANDING_FAIL:
      return updateObject(state, {
        showSpinner: false,
        getManageError: true
      })  

    case FETCH_MTNS_SUCCESS:
      return updateObject(state, {
        mtns: action.response.mtnList
    })
    case REMOVE_MANAGER_BEGIN:
      return {
        ...state,
        userVerified: null,
        removeManagerSpinner: true
      }
    case REMOVE_MANAGER_SUCCESS:
      const { phoneNumber, emailId, firstName, lastName } = action.payload;

      if(isNaN(parseInt(phoneNumber))){
        return {
          ...state,
          revokedManager: action.payload,
          managers: state.managers.filter(item => (item.firstName.toUpperCase() !== firstName && item.lastName.toUpperCase() !== lastName) || item.phoneNumber !== phoneNumber),
          removeManagerSpinner: false,
          removeManagerError: {},
        }
      } else {
        return {
          ...state,
          revokedManager: action.payload,
          managers: state.managers.filter(item => (item.firstName.toUpperCase() !== firstName && item.lastName.toUpperCase() !== lastName) || item.phoneNumber !== phoneNumber),
          removeManagerSpinner: false,
          removeManagerError: {},
          mtns: [...state.mtns, { mdn: action.payload.phoneNumber, encryptedMdn: action.payload.encryptedPhoneNumber }]
        }
      }

    case REMOVE_MANAGER_FAIL:
      return {
        ...state,
        removeManagerSpinner: false,
        removeManagerError: action.payload
      }
    case UNDO_REMOVE_MANAGER_BEGIN:
      return {
        ...state,
        showSpinner: true
      }
    case UNDO_REMOVE_MANAGER_SUCCESS:
    const newMtns = state.mtns.filter(item => item.encryptedMdn !== action.payload.encryptedPhoneNumber)
      return {
        ...state,
        showSpinner: false,
        revokedManager: {},
        managers: [...state.managers, action.payload],
        undoRemoveManagerError: {},
        mtns: newMtns
      }
    case UNDO_REMOVE_MANAGER_FAIL:
      return {
        ...state,
        showSpinner: false,
        undoRemoveManagerError: action.payload
      }
    case FETCH_MANAGER_REQUESTS_SUCCESS:
      let accountManagerRequests = []
      action.response.customerInfo.forEach(eachManager => {
        if( eachManager.role === 'mobileSecure' ){
          accountManagerRequests.push(eachManager)
        }
      })
      return updateObject(state, {
        accountManagerRequests
      })
    case SEND_ACCOUNT_MANGER_REQUEST_BEGIN: {
      return {
        ...state,
        showSpinner: true
      }
    }
    case SEND_ACCOUNT_MANGER_REQUEST_SUCCESS:
    const managerRequest = state.deniedAccountManagerRequests.find(item => item.encryptedPhoneNumber === action.response.encryptedPhoneNumber)
      return {
        ...state,
        showSpinner: false,
        accountManagerRequests: [...state.accountManagerRequests, managerRequest],
        deniedAccountManagerRequests: state.deniedAccountManagerRequests.filter(item => item.encryptedPhoneNumber !== action.response.encryptedPhoneNumber),
        sendAccountManagerRequestError: ""
      }
    case SEND_ACCOUNT_MANGER_REQUEST_FAIL: 
      return {
        ...state,
        showSpinner: false,
        sendAccountManagerRequestError: action.payload
      }
    case GET_ACCOUNT_MEMBER_DETAILS_SUCCESS :
    return updateObject(state, {
      emailId: action.response.emailId,
      phoneNumber: action.response.phoneNumber,
      encryptedPhoneNumber: action.response.encryptedPhoneNumber,
      newAccountMemberRequest : {
        status: action.response.hasPendingRequests ? 'request pending' : 'not requested'
      }
    })
    case SHOW_LEARN_MORE_POPUP:
      return updateObject(state, {
        showLearnMorePopUp: true
    })
    case HIDE_LEARN_MORE_POPUP:
      return updateObject(state, {
        showLearnMorePopUp: false
    })
    default:
      return state
  }
}

export default accManagerReducer
